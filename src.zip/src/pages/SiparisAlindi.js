import React from "react";
import "./SiparisAlindi.css";
const SiparisAlindi = () => {
  return (
    <div className="siparis">
      <p>TEBRİKLER</p>
      <p>SİPARİŞİNİZ ALINDI</p>
    </div>
  );
};
export default SiparisAlindi;
