import React from "react";
const AnaSayfa = () => {
  return (
    <div className="anasayfa">
      <img src="../Assets/mvp-banner.png" alt="Anasayfa pizza resmi" />
      <div className="paragraphs">
        <p className="kodAciktirir">KOD ACIKTIRIR</p>
        <p className="pizzaDoyurur">PİZZA, DOYURUR</p>
        <p className="aciktim">ACIKTIM</p>
      </div>
    </div>
  );
};
export default AnaSayfa;
