/* import React, { useState } from "react";
import {
  Dropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
} from "reactstrap";
function DropdownFunction(props) {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const toggle = () => setDropdownOpen((prevState) => !prevState);
  return (
    <Dropdown isOpen={dropdownOpen} toggle={toggle} {...props}>
      <DropdownToggle caret size="lg">
        Hamur Kalınlığı
      </DropdownToggle>
      <DropdownMenu>
        <DropdownItem header>Hamur Kalınlığı</DropdownItem>
        <DropdownItem>İnce</DropdownItem>
        <DropdownItem>Normal</DropdownItem>
        <DropdownItem>Kalın</DropdownItem>
      </DropdownMenu>
    </Dropdown>
  );
}
export default DropdownFunction; */
